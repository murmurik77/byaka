﻿using System.Collections.Generic;
using System.Windows;

namespace KomfortWpf
{
    public partial class WorkshopsWindow : Window
    {
        public WorkshopsWindow(List<WorkshopInfo> workshops)
        {
            InitializeComponent();
            WorkshopList.ItemsSource = workshops;
        }
    }
}
