﻿using System.Collections.Generic;
using System.Windows;

namespace KomfortWpf
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadProducts();
        }

        private void LoadProducts()
        {
            List<Product> products = Database.GetAllProducts();
            ProductList.ItemsSource = products;
        }

        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            var form = new ProductForm();
            if (form.ShowDialog() == true)
                LoadProducts();
        }

        private void EditProduct_Click(object sender, RoutedEventArgs e)
        {
            if (sender is FrameworkElement element && element.DataContext is Product selectedProduct)
            {
                var form = new ProductForm(selectedProduct);
                if (form.ShowDialog() == true)
                    LoadProducts();
            }
        }

        private void ShowWorkshops_Click(object sender, RoutedEventArgs e)
        {
            if (sender is FrameworkElement element && element.DataContext is Product product)
            {
                var window = new WorkshopsWindow(product.Workshops);
                window.ShowDialog();
            }
        }
    }
}
