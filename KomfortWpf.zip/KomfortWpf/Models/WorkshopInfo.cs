﻿namespace KomfortWpf
{
    public class WorkshopInfo
    {
        public string WorkshopName { get; set; }
        public int WorkersCount { get; set; }
        public double ProductionTime { get; set; }

        public override string ToString()
        {
            return $"{WorkshopName}: {WorkersCount} чел., {ProductionTime} ч";
        }
    }
}
