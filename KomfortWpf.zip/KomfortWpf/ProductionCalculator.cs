﻿using System;
using System.Data.SqlClient;

namespace KomfortWpf
{
    public static class ProductionCalculator
    {
        private static readonly string connectionString =
            @"Data Source=(localdb)\mssqllocaldb;Initial Catalog=Comfort;Integrated Security=True";

        public static int CalculateMaterialAmount(int productTypeId, int materialTypeId, int quantity,
                                                  double param1, double param2)
        {
            if (quantity <= 0 || param1 <= 0 || param2 <= 0)
                return -1;

            double? GetValue(SqlConnection conn, string sql, int id)
            {
                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    var result = cmd.ExecuteScalar();
                    if (result != null)
                        return (double?)Convert.ToDouble(result);
                    return null;
                }
            }

            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();

                var coefficient = GetValue(conn, "SELECT Coefficient FROM ProductType WHERE Id = @id", productTypeId);
                var lossPercent = GetValue(conn, "SELECT LossPercent FROM MaterialType WHERE Id = @id", materialTypeId);

                if (coefficient == null || lossPercent == null)
                    return -1;

                double basePerUnit = param1 * param2 * coefficient.Value;
                double total = basePerUnit * quantity;
                double withLoss = total * (1 + lossPercent.Value / 100.0);

                return (int)Math.Ceiling(withLoss);
            }
        }
    }
}
