﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;

namespace KomfortWpf
{
    public partial class ProductForm : Window
    {
        private readonly Product _editingProduct;
        private readonly string connectionString =
            @"Data Source=(localdb)\mssqllocaldb;Initial Catalog=Comfort;Integrated Security=True";

        private Dictionary<int, string> productTypes = new Dictionary<int, string>();
        private Dictionary<int, string> materialTypes = new Dictionary<int, string>();

        public ProductForm()
        {
            InitializeComponent();
            LoadProductTypes();
            LoadMaterialTypes();
        }

        public ProductForm(Product product) : this()
        {
            _editingProduct = product;
            Title = "Редактирование продукта";

            ArticleBox.Text = product.Article;
            NameBox.Text = product.ProductName;
            PriceBox.Text = product.PartnerPrice.ToString();
            ProductTypeBox.Text = product.ProductTypeName;
            MaterialBox.Text = product.MaterialTypeName;
        }

        private void LoadProductTypes()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                var cmd = new SqlCommand("SELECT Id, Name FROM ProductType", conn);
                var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    int id = Convert.ToInt32(reader["Id"]);
                    string name = reader["Name"].ToString();
                    productTypes[id] = name;
                    ProductTypeBox.Items.Add(name);
                }

                reader.Close();
            }
        }

        private void LoadMaterialTypes()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                var cmd = new SqlCommand("SELECT Id, Name FROM MaterialType", conn);
                var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    int id = Convert.ToInt32(reader["Id"]);
                    string name = reader["Name"].ToString();
                    materialTypes[id] = name;
                    MaterialBox.Items.Add(name);
                }

                reader.Close();
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            string article = ArticleBox.Text.Trim();
            string name = NameBox.Text.Trim();
            if (!decimal.TryParse(PriceBox.Text.Trim(), out decimal price) || price < 0)
            {
                MessageBox.Show("Некорректная цена", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int? productTypeId = FindKeyByValue(productTypes, ProductTypeBox.Text);
            int? materialTypeId = FindKeyByValue(materialTypes, MaterialBox.Text);

            if (productTypeId == null || materialTypeId == null)
            {
                MessageBox.Show("Выберите корректные значения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                SqlCommand cmd;

                if (_editingProduct == null)
                {
                    cmd = new SqlCommand(@"
                        INSERT INTO Products (ProductTypeId, ProductName, Article, PartnerPrice, MaterialTypeId)
                        VALUES (@ProductTypeId, @ProductName, @Article, @PartnerPrice, @MaterialTypeId)", conn);
                }
                else
                {
                    cmd = new SqlCommand(@"
                        UPDATE Products
                        SET ProductTypeId = @ProductTypeId,
                            ProductName = @ProductName,
                            PartnerPrice = @PartnerPrice,
                            MaterialTypeId = @MaterialTypeId
                        WHERE Article = @Article", conn);
                }

                cmd.Parameters.AddWithValue("@ProductTypeId", productTypeId.Value);
                cmd.Parameters.AddWithValue("@ProductName", name);
                cmd.Parameters.AddWithValue("@Article", article);
                cmd.Parameters.AddWithValue("@PartnerPrice", price);
                cmd.Parameters.AddWithValue("@MaterialTypeId", materialTypeId.Value);

                cmd.ExecuteNonQuery();
            }

            DialogResult = true;
            Close();
        }

        private int? FindKeyByValue(Dictionary<int, string> dict, string value)
        {
            foreach (var pair in dict)
            {
                if (pair.Value == value)
                    return pair.Key;
            }
            return null;
        }
    }
}
