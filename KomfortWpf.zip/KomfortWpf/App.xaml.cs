﻿using System.Windows;

namespace KomfortWpf
{
    public partial class App : Application
    {
    }
}
