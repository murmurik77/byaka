﻿using System.Collections.Generic;

namespace KomfortWpf
{
    public class Product
    {
        public string ProductName { get; set; }
        public string ProductTypeName { get; set; }
        public string Article { get; set; }
        public decimal PartnerPrice { get; set; }
        public string MaterialTypeName { get; set; }
        public double ProductionTime { get; set; }

        // Дополнительные свойства для отображения
        public string ProductionTimeText => $"{ProductionTime} ч";
        public string ProductDisplay => $"{ProductTypeName} | {ProductName}";

        // Цеха для этого изделия
        public List<WorkshopInfo> Workshops { get; set; } = new List<WorkshopInfo>();
    }
}
