﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace KomfortWpf
{
    public static class Database
    {
        private static readonly string connectionString =
            @"Data Source=(localdb)\mssqllocaldb;Initial Catalog=Comfort;Integrated Security=True";

        public static List<Product> GetAllProducts()
        {
            var products = new List<Product>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Основной запрос по продукции
                string productQuery = @"
                    SELECT 
                        p.ProductName,
                        pt.Name AS ProductTypeName,
                        p.Article,
                        p.PartnerPrice,
                        mt.Name AS MaterialTypeName,
                        ISNULL(SUM(pw.ProductionTime), 0) AS ProductionTime
                    FROM Products p
                    JOIN ProductType pt ON p.ProductTypeId = pt.Id
                    JOIN MaterialType mt ON p.MaterialTypeId = mt.Id
                    LEFT JOIN ProductWorkshops pw ON pw.ProductNameId = p.Id
                    GROUP BY p.ProductName, pt.Name, p.Article, p.PartnerPrice, mt.Name";

                SqlCommand command = new SqlCommand(productQuery, connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    var product = new Product
                    {
                        ProductName = reader["ProductName"].ToString(),
                        ProductTypeName = reader["ProductTypeName"].ToString(),
                        Article = reader["Article"].ToString(),
                        PartnerPrice = Convert.ToDecimal(reader["PartnerPrice"]),
                        MaterialTypeName = reader["MaterialTypeName"].ToString(),
                        ProductionTime = Convert.ToDouble(reader["ProductionTime"])
                    };

                    products.Add(product);
                }

                reader.Close();

                // Загрузка цехов для каждого продукта
                foreach (var product in products)
                {
                    string workshopQuery = @"
                        SELECT w.Name, w.WorkersCount, pw.ProductionTime
                        FROM ProductWorkshops pw
                        JOIN Workshops w ON w.Id = pw.WorkshopId
                        JOIN Products p ON p.Id = pw.ProductNameId
                        WHERE p.Article = @Article";

                    using (SqlCommand workshopCmd = new SqlCommand(workshopQuery, connection))
                    {
                        workshopCmd.Parameters.AddWithValue("@Article", product.Article);
                        var wr = workshopCmd.ExecuteReader();

                        while (wr.Read())
                        {
                            product.Workshops.Add(new WorkshopInfo
                            {
                                WorkshopName = wr["Name"].ToString(),
                                WorkersCount = Convert.ToInt32(wr["WorkersCount"]),
                                ProductionTime = Convert.ToDouble(wr["ProductionTime"])
                            });
                        }

                        wr.Close();
                    }
                }
            }

            return products;
        }
    }
}
